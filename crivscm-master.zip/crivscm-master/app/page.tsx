"use client"

import EnhancedCRIvsCRMComparison from "../enhanced-cri-vs-crm-comparison"

export default function SyntheticV0PageForDeployment() {
  return <EnhancedCRIvsCRMComparison />
}